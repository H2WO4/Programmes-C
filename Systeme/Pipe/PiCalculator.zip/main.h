/**
 * Author: Arthur Lamidel
 * 
 * Defines constants for the program
 */

#define PRECISION 1000000
